// Grzegorz Kodrzycki 332834
int send_packet(int sock_fd, int TTL, int id, struct sockaddr_in *dest_addr);